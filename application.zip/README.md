Forked from https://github.com/MattSkala/html5-bombergirl

License
-------
The source code is licensed under MIT License. The game soundtrack is licensed under Creative Commons Attribution-ShareAlike 4.0 International License.
![CC BY-SA](http://i.creativecommons.org/l/by-sa/4.0/80x15.png).

Credits
-------
[Tile Art Batch by Hyptosis](http://www.newgrounds.com/art/view/hyptosis/tile-art-batch-1)<br>
[Alternate LPC Character Sprites George by sheep](http://opengameart.org/content/alternate-lpc-character-sprites-george)<br>
[One More LPC Alternate Character by Radomir Dopieralski](http://opengameart.org/content/one-more-lpc-alternate-character)<br>
[Explosion Sound Effect by Adrian Gallant](http://www.flashkit.com/soundfx/Cartoon/Explosions/Explosio-Adrian_G-7936)
